/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 11, 2015, 1:54 PM
 * Purpose: Make a square display using loop
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv) {
    //Declare variables
    int num;
    
    //Prompt user input
    cout<<"Input an integer no greater than 15."<<endl;
    cin>>num;
    switch(num){
    case 1: cout<<"X"<<endl;
            break;
    case 2: cout<<"XX"<<endl;
            cout<<"XX"<<endl;
            break;
    case 3: cout<<"XXX"<<endl;
            cout<<"XXX"<<endl;
            cout<<"XXX"<<endl;
            break;
    case 4: cout<<"XXXX"<<endl;
            cout<<"XXXX"<<endl;
            cout<<"XXXX"<<endl;
            cout<<"XXXX"<<endl;
            break;
    case 5: cout<<"XXXXX"<<endl;
            cout<<"XXXXX"<<endl;
            cout<<"XXXXX"<<endl;
            cout<<"XXXXX"<<endl;
            cout<<"XXXXX"<<endl;
            break;
    case 6: cout<<"XXXXXX"<<endl;
            cout<<"XXXXXX"<<endl;
            cout<<"XXXXXX"<<endl;
            cout<<"XXXXXX"<<endl;
            cout<<"XXXXXX"<<endl;
            cout<<"XXXXXX"<<endl;
            break;
    case 7: cout<<"XXXXXXX"<<endl;
            cout<<"XXXXXXX"<<endl;
            cout<<"XXXXXXX"<<endl;
            cout<<"XXXXXXX"<<endl;
            cout<<"XXXXXXX"<<endl;
            cout<<"XXXXXXX"<<endl;
            cout<<"XXXXXXX"<<endl;
            break;
    case 8: cout<<"XXXXXXXX"<<endl;
            cout<<"XXXXXXXX"<<endl;
            cout<<"XXXXXXXX"<<endl;
            cout<<"XXXXXXXX"<<endl;
            cout<<"XXXXXXXX"<<endl;
            cout<<"XXXXXXXX"<<endl;
            cout<<"XXXXXXXX"<<endl;
            cout<<"XXXXXXXX"<<endl;
            break;
    case 9: cout<<"XXXXXXXXX"<<endl;
            cout<<"XXXXXXXXX"<<endl;
            cout<<"XXXXXXXXX"<<endl;
            cout<<"XXXXXXXXX"<<endl;
            cout<<"XXXXXXXXX"<<endl;
            cout<<"XXXXXXXXX"<<endl;
            cout<<"XXXXXXXXX"<<endl;
            cout<<"XXXXXXXXX"<<endl;
            cout<<"XXXXXXXXX"<<endl;
            break;
    case 10:cout<<"XXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXX"<<endl;
            break;
    case 11:cout<<"XXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXX"<<endl;
            break;
    case 12:cout<<"XXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXX"<<endl;
            break;
    case 13:cout<<"XXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXX"<<endl;
        break;
    case 14:cout<<"XXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXX"<<endl;
           break;
    case 15:cout<<"XXXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXXX"<<endl;
            cout<<"XXXXXXXXXXXXXXX"<<endl;
            break;
    default:cout<<"Not valid number."<<endl; 
    }
    return 0;
}

