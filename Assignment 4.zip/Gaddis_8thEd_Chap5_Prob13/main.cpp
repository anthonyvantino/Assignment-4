/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 1, 2015, 2:30 AM
 * Purpose: Find the least and greatest
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv) {
    //Declare variables
    unsigned int small;
    unsigned int nums;
    unsigned int large;
    
    //Prompt user input
    cout<<"Enter a series of integers. Enter -99 when finished."<<endl;
    cin>>nums;
    if(nums == -99){
        return 0;
    }
    small = nums;
    large = nums;
    while(1==1){
        cin>>nums;
        if(nums==-99)
            break;
        if(large<nums)
            large = nums;
        else if(small>nums)
            small = nums;
    }
    cout<<"The smallest number entered = "<<small<<endl;
    cout<<"The largest number entered = "<<large<<endl;
    return 0;
}

