/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 10, 2015, 1:59 PM
 * Purpose: Find the sum of 1 - number entered 
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variables
    unsigned int numEnt;    //Positive Int number entered
    unsigned int numAdd;    //Number 1 - numEnt 
    int sum;                //Sum of all numbers
    
    cout<<"Enter a positive integer."<<endl;
    cin>>numEnt;
    
    //Loop
    for(numAdd = 1; numAdd<=numEnt; numAdd++){
        sum +=numAdd;
    }while(numAdd<=numEnt);
    
    //Output the results
    cout<<"Sum of all the number leading up to the integer = "<<sum<<endl;
    
    //Winter is Coming!
    return 0;
}

