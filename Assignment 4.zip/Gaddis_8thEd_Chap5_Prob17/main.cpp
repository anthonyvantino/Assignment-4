/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 1, 2015, 2:30 AM
 * Purpose: Display a bar graph
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv) {
    //Declare variables
    unsigned int sales1;
    unsigned int sales2;
    unsigned int sales3;
    unsigned int sales4;
    unsigned int sales5;
    int count1;
    int count2;
    int count3;
    int count4;
    int count5;
    
   
        //Prompt user input   
        cout<<"Enter today's sales for store 1: ";
        cin>>sales1;
        cout<<"Enter today's sales for store 2: ";
        cin>>sales2;
        cout<<"Enter today's sales for store 3: ";
        cin>>sales3;
        cout<<"Enter today's sales for store 4: ";
        cin>>sales4;
        cout<<"Enter today's sales for store 5: ";
        cin>>sales5;
        
        //Display Output
    cout<<"SALES BAR CHART"<<endl;
    cout<<"(Each * = $100)"<<endl;
    cout<<"Store 1: ";
        for(int count1 = 1; count1 <= (sales1/100); count1++){
            cout<<"*";
        }
        cout<<endl;
        cout<<"Store 2: ";
        for(int count2 = 1; count2 <= (sales2/100); count2++){
            cout<<"*";
        }
        cout<<endl;
        cout<<"Store 3: ";
        for(int count3 = 1; count3 <= (sales3/100); count3++){
            cout<<"*";
        }
        cout<<endl;
        cout<<"Store 4: ";
        for(int count4 = 1; count4 <= (sales4/100); count4++){
            cout<<"*";
        }
        cout<<endl;
        cout<<"Store 5: ";
        for(int count5 = 1; count5 <= (sales5/100); count5++){
            cout<<"*";
        }
        cout<<endl;
    return 0;
}
