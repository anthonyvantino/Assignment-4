/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 1, 2015, 2:30 AM
 * Purpose: Play a random number guessing game
 */

//System Libraries
#include <iostream>
#include <cstdlib>
using namespace std;

//User Libraries

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv) {
    //Declare variables
    unsigned int guess;
    unsigned int num;
    
    
  //initialize random seed
  srand (time(0));

 //generate secret number between 1 and 10
  num = rand() % 10 + 1;

  while (num!=guess){
      //Prompt User input
    cout<<"The computer has generated a random number between 1 - 10. "
            "Try to guess the number."<<endl<<endl;
    cin>>guess;
    
    if (num<guess)
        cout<<"The secret number is lower"<<endl<<endl;
    else if (num>guess)
        cout<<"The secret number is higher"<<endl<<endl;
        if (guess<=0){
            cout<<"Number too small. Try again."<<endl;
        }
        if (guess>10){
            cout<<"Number is too high. Try again."<<endl;
        }
    }
  cout<<"Congratulations!"<<"The number was "<<num<<'.'
          <<" You ARE smarter than a computer!"<<endl;
    
    return 0;
}

