/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 1, 2015, 1:54 AM
 * Purpose: Calculate Monthly Budget
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv) {
    //Declare variables
    float budge;         //Monthly Budget
    int weeks = 4;     //The weeks of the month 
    float total = 0.0; //Accumulator
    float endBudg;       //How much your budget is under||over
    
    //Prompt user input
    cout<<"What is your monthly budget?"<<endl;
    cin>>budge;
    
    for (int count = 1; count<= weeks; count++){
        float expns;    //Expenses for the month
        cout<<"Enter the expenses for the week "<<count<<": ";
        cin>>expns;
        total += expns;
    }
    endBudg=budge-total;
    //Display Output
    cout<<fixed<<showpoint<<setprecision(2);
    if (endBudg<0)
        cout<<"At the end of the month your budget will be under $"<<endBudg<<endl;
    else
        cout<<"At the end of the month your budget will be over $"<<endBudg<<endl;
    return 0;
}

