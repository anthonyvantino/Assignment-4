/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 10, 2015, 3:40 PM
 * Purpose: Calculate 4% increase each year
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variables
    unsigned int mem1 = 2500;
    unsigned int mem2;
    unsigned int mem3;
    unsigned int mem4;
    unsigned int mem5;
    unsigned int mem6;
    unsigned int mem7;
    unsigned int memTot;
    float inc = 0.04f;
    unsigned int year = 0;
    
    do{
        mem2=mem1+(mem1*inc);
        mem3=mem2+(mem2*inc);
        mem4=mem3+(mem3*inc);
        mem5=mem4+(mem4*inc);
        mem6=mem5+(mem5*inc);
        mem7=mem6+(mem6*inc);
        year++;
    }while(year>=5);
    
    //Output Results
    cout<<"Initial Membership = $"<<mem1<<endl;
    cout<<"The first year membership will increase to"<<setw(2)<<'$'<<mem2<<endl;
    cout<<"The second year membership will increase to"<<setw(2)<<'$'<<mem3<<endl;
    cout<<"The third year membership will increase to"<<setw(2)<<'$'<<mem4<<endl;
    cout<<"The fourth year membership will increase to"<<setw(2)<<'$'<<mem5<<endl;
    cout<<"The fifth year membership will increase to"<<setw(2)<<'$'<<mem6<<endl;
    cout<<"The sixth year membership will increase to"<<setw(2)<<'$'<<mem7<<endl;
    
        return 0;
}
