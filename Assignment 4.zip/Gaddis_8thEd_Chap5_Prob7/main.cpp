/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 11, 2015, 3:40 PM
 * Purpose: Calculate pennies per day
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variables
    float penny1 = 0.01;
    float penny2 = 0.01;
    float days = 0;
    float dayWrk;
    float salary;
    float totPay;
    
    //Prompt user for input
    cout<<"How many days have you worked?"<<endl;
    cin>>dayWrk;
    
    cout<<"Days worked"<<setw(15)<<"Money earned"<<endl;
    
    //Loop
    do{
        days++;
        penny2=penny1*2;
        totPay=salary;
        cout<<days<<setw(15)<<salary<<endl;
    }while(penny2<=days);
    
    //Output the results
    cout<<"You will earn = "<<totPay<<" pennies on pay day"<<endl;
    return 0;
}

