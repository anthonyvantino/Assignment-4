/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 10, 2015, 2:40 PM
 * Purpose: Find how much the ocean has risen in 25yrs 
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variables
    float cal;
    unsigned int min = 0;
    
    //Loop
    do{    
        cal=cal+3.6;
        min++;
            switch (min){
            case 5: cout<<"After 5 minutes you burn "<<cal<<"(cal)"<<endl;
                break;
            case 10: cout<<"After 10 minutes you burn "<<cal<<"(cal)"<<endl;
                break;
            case 15: cout<<"After 15 minutes you burn "<<cal<<"(cal)"<<endl;
                break;
            case 20: cout<<"After 20 minutes you burn "<<cal<<"(cal)"<<endl;
                break;
            case 25: cout<<"After 25 minutes you burn "<<cal<<"(cal)"<<endl;
                break;
            case 30: cout<<"After 30 minutes you burn "<<cal<<"(cal)"<<endl;
                break;
            //default: cout<<"Number not valid"<<endl;
            }  
    }while(min<=29);
    
    return 0;
}

