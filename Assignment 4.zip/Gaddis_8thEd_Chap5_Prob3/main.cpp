/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 10, 2015, 2:40 PM
 * Purpose: Find how much the ocean has risen in 25yrs 
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare variables
    float ocnRise;          //Ocean rising 1.5millimeters per year
    unsigned int year = -1; //25 years of calculations
    
    cout<<"Year"<<"  Ocean Rising (ml)"<<endl;
    //Loop
    do{    
        ocnRise=ocnRise+1.5;
        year++;
        //Table
    cout<<fixed<<showpoint<<setprecision(2)<<year<<setw(13)<<ocnRise<<endl;
    }while(year<=24);
       
return 0;
}

